import "./styles.css";

import NavBarHeader from "./Components/JS/NavBarHeader";
export default function App() {
  return (
    <>
      <div className="App">
        <NavBarHeader />
      </div>
    </>
  );
}
