import "./../CSS/Navbar.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import { Navbar } from "./Navbar.1";

export default Navbar;
